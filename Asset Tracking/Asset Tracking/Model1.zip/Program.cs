﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace Asset_Tracking
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            dbEntities db = null;

            try
            {
                db = DatabaseConnection.CreateContext();

                if (!db.assets.Any())
                {
                    // Database is accessible, even if it is empty.
                }

                Application.Run(new MainPage(db));
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    "Cannot access the database.\r\n\r\n" + exception.Message,
                    "Database Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                db?.Dispose();
                DatabaseConnection.CreateContext().Dispose();
            }
        }
    }
}
